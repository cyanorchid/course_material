

#include 	"msp430f5529.h"
#include  	"key.h"

static	enum    key_type key_value = NOKEY;
enum key_type	KeyScan(void)
{
        
	if( KEY_L )	
            key_value = KEYLEFT;
        
	else if( KEY_R )		
            key_value = KEYRIGHT;
        
        else
            key_value = NOKEY;
        
	return	key_value;
}
